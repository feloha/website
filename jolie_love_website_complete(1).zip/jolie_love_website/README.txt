JOLIE LOVE WEBSITE

1. Open index.html in a browser.
2. Password: felolovesjolie

ADDING PHOTOS AND VIDEOS
- Open index.html in a text editor.
- Search for: CUSTOMISE YOUR CONTENT HERE
- Add paths such as:
    media: "media/letters/01-sick.jpg"
    mediaType: "image"

  or:
    media: "media/memories/first-date.mp4"
    mediaType: "video"

RECOMMENDED FOLDERS
- media/hero
- media/letters
- media/memories
- media/audio

ADDING YOUR SONG
- Put an MP3 in media/audio.
- Change:
    const OUR_SONG = "";
  to:
    const OUR_SONG = "media/audio/our-song.mp3";

HOSTING
- Upload the entire folder to Netlify, GitHub Pages, or Cloudflare Pages.
